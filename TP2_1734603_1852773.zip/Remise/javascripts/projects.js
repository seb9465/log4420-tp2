
/* jQuery selector for the projects navigation link in the header */
const projectsLinkSelector = '#projects-link';

$(document).ready(() => {
	$(projectsLinkSelector).addClass('active');
});
