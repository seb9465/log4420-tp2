
/* jQuery selector for the team navigation link in the header */
const teamLinkSelector = '#team-link';

$(document).ready(() => {
	$(teamLinkSelector).addClass('active');
});
