# TP2 LOG4420

Ce travail contient le code source pour le travail pratique 2 du cours LOG4420.

Assurez-vous que Node/NPM est installé sur votre système.

À partir de la racine de ce dossier, exécuter la commande `npm install` pour installer les dépendances du projet.
Ensuite, vous pouvez déployer le site web avec `npm start` qui le rendra disponible à l'URL `http://localhost:3000`.

Pour lancer les tests unitaires, exécutez la commande `npm test`.

Pour lancer les tests seleniums, exécutez la commande `npm run e2e`.
